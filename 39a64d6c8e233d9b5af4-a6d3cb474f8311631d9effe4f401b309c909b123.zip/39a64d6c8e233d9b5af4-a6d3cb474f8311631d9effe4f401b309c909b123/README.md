A simple Webpack + Gulpfile configuration wihtout any need for React.js that assumes you have the following project structure:

`node_modules/`
`bower_components/`
`scripts/`

Entry script is in `scripts/entry.js`

You should run `gulp && gulp build-dev` and you are good to go.
